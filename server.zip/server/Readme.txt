Για να τρέξει ο server:
npm i --save-dev nodemon dotenv
npm i express ejs bcrypt passport passport-local express-session express-flash method-override
npm run start



Για να δεις τους χρήστες που έχουν εγγραφεί τρέχεις console.log(users). Αν δεν υπάρχει βάση δεδομένων, η μεταβλητή αδειάζει στην επανεκκίνηση του server

Η σελίδα εμφανίζεται γράφοντας ως URL το "localhost:3000"